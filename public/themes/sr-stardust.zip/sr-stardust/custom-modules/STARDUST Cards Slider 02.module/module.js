document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.sr-cards-slider-02 .splide').forEach(el => {
        // Create the Splide instance first and store it in a variable
        const splide = new Splide(el, {
			pauseOnHover: false,
			pauseOnFocus: false,
            arrows: el.dataset.arrows == 'true' ? true : false,
            pagination: el.dataset.pagination == 'true' ? true : false,
            autoplay: el.dataset.autoplay == 'true' ? true : false,
            interval: +el.dataset.autoplayspeed * 1000,
            type: 'loop',
            gap: '30px',
            autoWidth: true,
            padding: '0',
			trimSpace: false ,
            rewind: el.dataset.fade == 'true' ? true : false,
            snap: el.dataset.scroll == 'true' ? false : true,
            autoScroll: {
                speed: +el.dataset.scrollspeed,
            },
            breakpoints: {
				993: {
                   perPage: 1,
                   autoWidth: false,
                }
            }
        });

        // Attach event listeners to the Splide instance before mounting
        splide.on('ready', function () {
            console.log('ready', el);
            const sliderContent = el.querySelector('.slider-content-inner');
            const splideList = el.querySelector('.splide__list');

            // Get the height of sliderContent including padding
            const computedStyle = window.getComputedStyle(sliderContent);
            const contentHeight = sliderContent.offsetHeight + parseInt(computedStyle.paddingTop) + parseInt(computedStyle.paddingBottom);

            // Get the original height of splide__list
            const listHeight = splideList.offsetHeight;
            console.log('listHeight', listHeight);
            console.log('contentHeight', contentHeight);
            // Only set the min-height if sliderContent height is larger than splide__list height
            if (contentHeight > listHeight) {
                el.style.setProperty('--slider-min-height', `${contentHeight}px`);
            }
        });

        // Mount the Splide instance after attaching event listeners
        splide.mount(el.dataset.scroll == 'true' ? window.splide.Extensions : null);
    });
})