document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.sr-cards-testimonial-slider-01 .splide').forEach(el => {
        // Create the Splide instance first and store it in a variable
        const splide = new Splide(el, {
			pauseOnHover: false,
			pauseOnFocus: false,
            arrows: el.dataset.arrows == 'true' ? true : false,
            pagination: el.dataset.pagination == 'true' ? true : false,
            autoplay: el.dataset.autoplay == 'true' ? true : false,
            interval: +el.dataset.autoplayspeed * 1000,
            type: 'loop',
            gap: '30px',
            padding: '0',
            perPage: +el.dataset.perpage,
            perMove: 1,
			trimSpace: false ,
            rewind: el.dataset.fade == 'true' ? true : false,
            snap: el.dataset.scroll == 'true' ? false : true,
            autoScroll: {
                speed: +el.dataset.scrollspeed,
            },
            breakpoints: {
				993: {
                   perPage: 2
                },
                767: {
                    perPage: 1
                }
            }
        });

        // Mount the Splide instance after attaching event listeners
        splide.mount(el.dataset.scroll == 'true' ? window.splide.Extensions : null);
    });
})